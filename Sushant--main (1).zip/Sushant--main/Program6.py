try:
    a=10
    a.append(20)
except AttributeError:
    print("There is no such attribute")
