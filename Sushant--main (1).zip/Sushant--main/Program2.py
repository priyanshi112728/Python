try:
    a=10
    b=20
    c=30
    print(d)
except NameError:
    print("Not a valid variable")
