import re
d="python-3.4 vrsion0.5"
p=r'[0-9]'
res=re.findall(p,d)
print(res)
