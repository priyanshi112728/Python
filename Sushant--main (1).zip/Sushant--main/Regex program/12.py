import re
d="white spaces here"
p=r'[\s]'
res=re.findall(p,d)
print(res)
