mydict={}

def len3():
    return len(mydict)

def add3(k, v):
    mydict[k] = v
    return mydict

def keys3():
    return mydict.keys()

def values3():
    return mydict.values()
